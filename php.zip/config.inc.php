<?
DEFINE('LOGIN', 'root');
DEFINE('PASSWORD', '');
DEFINE('DB', 'fidyt');
DEFINE('BAZA', 'mysql');
?>
